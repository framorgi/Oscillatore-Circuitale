clear all;
close all;
clc;

%% Continuazione dell'equilibrio e individuazione della biforcazione fold

% valore dei parametro per cui si ha un solo equilibrio
global a b
a= 7;
b=1;
equil = [-1.633;0;1.633 ];
p= [a;b];
% inizializzo la continuazione dell'equilibrio partendo da un equilibrio
[x0, v0] = init_EP_EP(@foldnormalform, equil, p, 2);
% imposto le opzioni di continuazioni
opt = contset;
% >>>>>>>  singularities = 1 => rileva le biforcazioni
opt = contset(opt,'Singularities',1);
% numero massimo di passi di continuazioni
opt = contset(opt,'MaxNumPoints',300);
% ampiezza massima del passo di continuazione
opt = contset(opt, 'MaxStepSize', 1e-8);
% direzione
opt = contset(opt, 'backward', 1);
% continuazione vera e propria
[xE,vE,sE,hE,fE] = cont(@equilibrium, x0, v0, opt);
%   grafico
figure;
cpl(xE,vE,sE,[2 1]);
title(sprintf('Continuazione dell''equilibrio %.3f al variare di p.',equil));
xlabel('p'); ylabel('x');

pause;

%% Salvataggio dati
save foldnormalformcont.mat
