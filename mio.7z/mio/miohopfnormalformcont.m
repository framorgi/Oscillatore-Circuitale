clear all;
close all;
clc;

%% Continuazione dell'equilibrio e individuazione della biforcazione di Hopf
global a b
a= 7;
b=14;
% punto di equilibrio
equil = [1.633;0;-1.633 ];
% valore del parametro per cui l'equilibrio e' STABILE
p= [a;b];
% inizializzo la continuazione dell'equilibrio partendo da un equilibrio
[x0, v0] = init_EP_EP(@miohopfnormalform, equil, p, 1);
% imposto le opzioni di continuazioni
opt = contset;
% >>>>>>>  singularities = 1 => rileva le biforcazioni
opt = contset(opt,'Singularities',1);
% numero massimo di passi di continuazione
opt = contset(opt,'MaxNumPoints',300);
% direzione;
   opt = contset(opt, 'backward', 1);
% continuazione vera e propria
[xE,vE,sE,hE,fE] = cont(@equilibrium, x0, v0, opt);
%   grafico
figure;
cpl(xE,vE,sE,[3 1 2]);
title('Continuazione dell''equilibrio (0,0) al variare di $p$.','Interpreter','latex');
xlabel('$p$','Interpreter','latex');
ylabel('$x_1$','Interpreter','latex');
zlabel('$x_2$','Interpreter','latex');

%% Continuazione del ciclo che nasce dalla Hopf

% indice, nel vettore delle soluzioni, della soluzioni corrispondente alla
% hopf
indice = sE(2).index;
% coordinate dell'equilibrio nel punto di biforcazione
ptH = xE(1:2,indice);
% valore del parametro nel punto di biforcazione
pH = xE(3,indice);
% norma iniziale del ciclo (qualsiasi valore "piccolo" va bene)
h = 1e-4;
% numero di punti sul ciclo
ntst = 30;
% numero di collocazioni tra ogni coppia di punti
ncol = 4;
% inizializzo la continuazione del ciclo partendo dalla Hopf
[x0, v0] = init_H_LC(@miohopfnormalform, ptH, pH, 1, h, ntst, ncol);
% opzioni di continuazione
opt = contset;
opt = contset(opt, 'MinStepSize', 1e-4);
opt = contset(opt, 'MaxNumPoints', 100);
[xLC,vLC,sLC,hLC,fLC] = cont(@limitcycle, x0, v0, opt);
%   grafico
figure;
plotcycle(xLC,vLC,sLC,[size(xLC,1) 1 2]);
hold on;
cpl(xE,vE,sE,[3 1 2]);
title('Continuazione del ciclo al variare di $p$.','Interpreter','latex');
xlabel('$p$','Interpreter','latex');
ylabel('$x_1$','Interpreter','latex');
zlabel('$x_2$','Interpreter','latex');


%% Salvataggio dati
save miohopfnormalformcont.mat