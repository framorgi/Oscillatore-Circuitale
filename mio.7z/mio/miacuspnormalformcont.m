clear all;
close all;
clc;

%%
PRINT_MANIFOLD = 1;
%% Continuazione dell'equilibrio e individuazione della biforcazione fold

% valore dei parametro per cui si ha un solo equilibrio
p = [7;1];
r = roots([-1.633,0,1.633,p(2),p(1)]);
% punto di equilibrio    
for k=1:length(r)
    if isreal(r(k))
        equil = r(k);
        break;
    end
end
% inizializzo la continuazione dell'equilibrio partendo da un equilibrio
[x0, v0] = init_EP_EP(@miacuspnormalform, equil, p, 2);
% imposto le opzioni di continuazioni
opt = contset;
% >>>>>>>  singularities = 1 => rileva le biforcazioni
opt = contset(opt,'Singularities',1);
% numero massimo di passi di continuazioni
opt = contset(opt,'MaxNumPoints',55);
% continuazione vera e propria
[xE,vE,sE,hE,fE] = cont(@equilibrium, x0, v0, opt);
%   grafico
figure;
cpl(xE,vE,sE,[2 1]);
title(sprintf('Continuazione dell''equilibrio %.3f al variare di p_1.',equil));
xlabel('p_1'); ylabel('x');

pause;

%% Continuazione di una delle due biforcazioni fold

% indice, nel vettore delle soluzioni, della soluzioni corrispondente alla
% fold
indice = sE(2).index;
% coordinate dell'equilibrio nel punto di biforcazione
ptLP = xE(1,indice);
% valore del parametro nel punto di biforcazione
p(1) = xE(2,indice);
% inizializzo la continuazione della curva fold
[x0, v0] = init_LP_LP(@miacuspnormalform, ptLP, p, [1,2]);
% opzioni di continuazione
opt = contset;
opt = contset(opt, 'Singularities', 1);
opt = contset(opt, 'MinStepSize', 1e-4);
opt = contset(opt, 'MaxNumPoints', 300);
[xLP,vLP,sLP,hLP,fLP] = cont(@limitpoint, x0, v0, opt);

%% visualizzazione risultati

figure; hold on; view(3); grid on; box on;
sz = size(xLP(1,:));
minX = min(xLP(1,:))-0.5;
maxX = max(xLP(1,:))+0.5;
minP1 = min(xLP(2,:))-0.5;
maxP1 = max(xLP(2,:))+0.25;
minP2 = min(xLP(3,:))-0.25;
maxP2 = max(xLP(3,:))+0.25;

if PRINT_MANIFOLD
    load('manifold.mat','EQr');
    minX = -1.5 - 2;
    maxX = 1.5;
    minP1 = -1;
    maxP1 = 1;
    minP2 = -1;
    maxP2 = 1.5;
    cmap = [0.4*[1 1 1]; [0 0 0]; 0.6*[1 1 1]];
    p = patch(EQr);
    alpha(p,0.7);
    colormap(cmap);
    set(p,'FaceColor','interp','EdgeColor','none');
    camlight(125,65);
    lighting('phong');
end

    
cpl(xLP,vLP,sLP,[2,3,1]);
plot3(xLP(2,:),xLP(3,:),repmat(minX,sz),'r','LineWidth',2);
if ~ PRINT_MANIFOLD
    plot3(repmat(maxP1,sz),xLP(3,:),xLP(1,:),'r','LineWidth',2);
    plot3(xLP(2,:),repmat(maxP2,sz),xLP(1,:),'r','LineWidth',2);
end
title('Continuazione della biforcazione fold al variare di (p_1,p_2).');
xlabel('p_1'); ylabel('p_2'); zlabel('x');
axis([minP1,maxP1,minP2,maxP2,minX,maxX]);

%% Salvataggio dati
save cuspnormalformcont.mat
