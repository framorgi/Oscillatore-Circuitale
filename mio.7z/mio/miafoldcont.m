
clear all;
close all;
clc;
global a b
a= 7;
b=1;
equil = [-1.63;0;1.633 ];
p= [a;b];

%% Continuazione dell'equilibrio che si trova nel punto equil

[x0, v0] = init_EP_EP(@OCnormalform, equil, p,1);
    % imposto le opzioni di continuazioni
opt = contset;
% >>>>>>>  singularities = 1 => rileva le biforcazioni
opt = contset(opt,'Singularities',1);
% numero massimo di passi di continuazioni
opt = contset(opt,'MaxNumPoints',300);
% ampiezza massima del passo di continuazione
 opt = contset(opt, 'MaxStepSize', 1e-8);
% direzione
  opt = contset(opt, 'backward', 1);
% continuazione vera e propria
    [xE,vE,sE,hE,fE] = cont(@equilibrium, x0, v0, opt);
%      ofs=3;
%          ofs = ofs+1;
%          figure(ofs);
figure;
            
str ='Continuazione dell''equilibrio  al variare del parametro';
  title(str);
xlabel('p'); ylabel('x');
%str1 = ['continuazione dell''equilibrio=',num2str(equil),' al variare di b=',num2str(b)']';
%        text (1,1,str1)
cpl(xE,vE,sE,[2,1]);
%cpl(xE,vE,sE,x0);


%% Salvataggio dati
save miacont.mat