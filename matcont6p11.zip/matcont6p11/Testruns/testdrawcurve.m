cds=[];
[x,v,s]=cont(@curve,[1;0]);
cpl(x,v,s);