MyMLSystem=MyML
MyMLfunction=MyMLSystem{2}
MyMLjacobian=MyMLSystem{3}
MyMLjacobianp=MyMLSystem{4}
MyMLfunction(0,[0;0],30,10)
MyMLjacobian(0,[0;0],30,10)
MyMLjacobianp(0,[0;0],30,10)
