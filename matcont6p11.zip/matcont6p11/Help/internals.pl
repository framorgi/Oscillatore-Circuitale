# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/cite_BTHom2/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/NSEP1/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/Phase/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Doao:97/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/HHfig/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/mp1/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/Fig:Koperhom/;
$ref_files{$key} = "$dir".q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_report/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/s:bpcloc/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Stephanos/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/systeminput/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/dataflow/;
$ref_files{$key} = "$dir".q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:mp1/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_yuri/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/homorder/;
$ref_files{$key} = "$dir".q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_be/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/BPBPfig/;
$ref_files{$key} = "$dir".q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/Eq.NFfold/;
$ref_files{$key} = "$dir".q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_preprint/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/Eq.NFHopf/;
$ref_files{$key} = "$dir".q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BTHom3/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/TimeIntegration/;
$ref_files{$key} = "$dir".q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:PRC1/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/labelAdapt/;
$ref_files{$key} = "$dir".q|node26.html|; 
$noresave{$key} = "$nosave";

$key = q/cstr/;
$ref_files{$key} = "$dir".q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/s:stepsize/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/TSO/;
$ref_files{$key} = "$dir".q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GoSa5/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GeTe:92/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_chkusa/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Te:91/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Te:92/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/LPLCEP/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/s:bploc/;
$ref_files{$key} = "$dir".q|node49.html|; 
$noresave{$key} = "$nosave";

$key = q/fe2/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Koper95/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kumegosa/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/S4:maps/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/CaOs/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/LCcurvefig/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:bratuBP/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/PerNF-PD/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/s:lcex/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/Sec:Directories/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:Koperequil/;
$ref_files{$key} = "$dir".q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/secondbif2/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:ns62/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/Sec:MF/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/Ricatti/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/directories/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/fe1/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/Poinsec/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/s:sysdef/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/timin/;
$ref_files{$key} = "$dir".q|node37.html|; 
$noresave{$key} = "$nosave";

$key = q/pdc1/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GoSaHom/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TOMS/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:corr/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/form:cond/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:prediction/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/secondbif/;
$ref_files{$key} = "$dir".q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/s:hom/;
$ref_files{$key} = "$dir".q|node103.html|; 
$noresave{$key} = "$nosave";

$key = q/s:numcont/;
$ref_files{$key} = "$dir".q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_content/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:bpc1/;
$ref_files{$key} = "$dir".q|node99.html|; 
$noresave{$key} = "$nosave";

$key = q/toruseq/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/bp1/;
$ref_files{$key} = "$dir".q|node94.html|; 
$noresave{$key} = "$nosave";

$key = q/op1/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MoLe:81/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/Equilibrium/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/exhomoclinic/;
$ref_files{$key} = "$dir".q|node109.html|; 
$noresave{$key} = "$nosave";

$key = q/LimCycInit/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/pdsystem/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/s:sing/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/opNS/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/LPEP/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/bratu/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/pdc3/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/NSLC1fig/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/LPLC2fig/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GoSa6/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/minext/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/UserfunctionScr/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/Project/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/s:circle/;
$ref_files{$key} = "$dir".q|node113.html|; 
$noresave{$key} = "$nosave";

$key = q/Bratu/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/HomInt/;
$ref_files{$key} = "$dir".q|node108.html|; 
$noresave{$key} = "$nosave";

$key = q/prentLCBPC2fig/;
$ref_files{$key} = "$dir".q|node102.html|; 
$noresave{$key} = "$nosave";

$key = q/LPBPfig/;
$ref_files{$key} = "$dir".q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:bruss2/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/mp2/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/foldcont/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/SelCyc1/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/StLr/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/BP1/;
$ref_files{$key} = "$dir".q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/inclinationsystem/;
$ref_files{$key} = "$dir".q|node107.html|; 
$noresave{$key} = "$nosave";

$key = q/initbyinteg/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/GlobStruct/;
$ref_files{$key} = "$dir".q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ri:00/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GeTe:95/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Er:02/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/Eq:Koper/;
$ref_files{$key} = "$dir".q|node111.html|; 
$noresave{$key} = "$nosave";

$key = q/prentLCBPC1fig/;
$ref_files{$key} = "$dir".q|node102.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:PRC2/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:ns61/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_allgower/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/completelc/;
$ref_files{$key} = "$dir".q|node53.html|; 
$noresave{$key} = "$nosave";

$key = q/brloc/;
$ref_files{$key} = "$dir".q|node49.html|; 
$noresave{$key} = "$nosave";

$key = q/LPLPfig/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dedegoku/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:lp61/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/Dist/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/Hopfcont/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/Poinsection/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_willy/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/NSSR/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/pde/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AUTO/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:bratu/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/s:curvedef/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

$key = q/access/;
$ref_files{$key} = "$dir".q|node36.html|; 
$noresave{$key} = "$nosave";

$key = q/Catal2/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/odefiledynsys/;
$ref_files{$key} = "$dir".q|node33.html|; 
$noresave{$key} = "$nosave";

$key = q/integplot/;
$ref_files{$key} = "$dir".q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/s:lc/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/s:equi/;
$ref_files{$key} = "$dir".q|node45.html|; 
$noresave{$key} = "$nosave";

$key = q/PerNF-LP/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/s:cont/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/minextBPC/;
$ref_files{$key} = "$dir".q|node99.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Collocation/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/Ricattiblocks/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kugododh/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/ttorBPC4/;
$ref_files{$key} = "$dir".q|node102.html|; 
$noresave{$key} = "$nosave";

$key = q/s:singmat/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MATLAB/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/IniTimInt/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/brusslabel/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BTHom1/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/prentBPCfig/;
$ref_files{$key} = "$dir".q|node102.html|; 
$noresave{$key} = "$nosave";

$key = q/Equilcataloscillfig/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/Homoclinic/;
$ref_files{$key} = "$dir".q|node105.html|; 
$noresave{$key} = "$nosave";

$key = q/minextns/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/pdc2/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/s:locator/;
$ref_files{$key} = "$dir".q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:mp/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:lp62/;
$ref_files{$key} = "$dir".q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:circle/;
$ref_files{$key} = "$dir".q|node113.html|; 
$noresave{$key} = "$nosave";

$key = q/bpcloc/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/s:PRC/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_chku/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/sect844/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/SelCyc2/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/LCcurve2fig/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Me:02/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_DoFr/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/Catal1/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/fe3/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/MinimalHopf/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/s:processing/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/NSNS1fig/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/form:brus/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/ttorNeimarkSacker/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/PerNF-NS/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/s:cd2/;
$ref_files{$key} = "$dir".q|node92.html|; 
$noresave{$key} = "$nosave";

$key = q/cstrmodel/;
$ref_files{$key} = "$dir".q|node97.html|; 
$noresave{$key} = "$nosave";

$key = q/LPLC1fig/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/LPLC3fig/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/s:software/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/PDcurvefig/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/s:options/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/s:structure/;
$ref_files{$key} = "$dir".q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:mp2/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/bp2/;
$ref_files{$key} = "$dir".q|node94.html|; 
$noresave{$key} = "$nosave";

$key = q/fe4/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/form:initial/;
$ref_files{$key} = "$dir".q|node114.html|; 
$noresave{$key} = "$nosave";

$key = q/NSNSfig/;
$ref_files{$key} = "$dir".q|node91.html|; 
$noresave{$key} = "$nosave";

$key = q/tstadapt3/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/MLFasthom/;
$ref_files{$key} = "$dir".q|node110.html|; 
$noresave{$key} = "$nosave";

$key = q/prent9/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_FrRo/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_degokufr/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:bpc2/;
$ref_files{$key} = "$dir".q|node99.html|; 
$noresave{$key} = "$nosave";

$key = q/opLP/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/s:cd1/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_DGKD/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/PinClM/;
$ref_files{$key} = "$dir".q|node44.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dedifr/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/lcp1/;
$ref_files{$key} = "$dir".q|node53.html|; 
$noresave{$key} = "$nosave";

$key = q/FrRoGaPo/;
$ref_files{$key} = "$dir".q|node102.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_aspects/;
$ref_files{$key} = "$dir".q|node115.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:layers/;
$ref_files{$key} = "$dir".q|node30.html|; 
$noresave{$key} = "$nosave";

1;

