function matconthelp(varargin)
% NUMERIC Application M-file for numeric.fig
%    FIG = NUMERIC launch numeric GUI.
%    NUMERIC('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 14-Nov-2001 12:21:37
%global gds path_sys MC FigPos

errordlg('MatCont help is not available');
